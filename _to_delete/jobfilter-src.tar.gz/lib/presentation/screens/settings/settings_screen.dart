import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../application/state/job_history_controller.dart';
import '../../../application/state/settings_controller.dart';
import '../../../core/constants/app_constants.dart';
import '../../../domain/enums/distance_unit.dart';
import '../../../domain/enums/platform_type.dart';
import '../../widgets/hero_header.dart';
import '../../widgets/section_card.dart';
import '../../widgets/tinted_icon_circle.dart';
import '../debug/debug_screen.dart';
import '../permissions/permissions_screen.dart';
import '../simulation/simulation_screen.dart';

/// Driver Settings (spec section 5) plus the app-wide preferences (name,
/// platform selection, distance unit) and links to the guided permissions
/// setup, Simulation Mode, and the debug screen (debug builds only).
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  static const _quickPresets = [1.50, 1.75, 2.00, 2.25, 2.50, 3.00];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsControllerProvider);
    final controller = ref.read(settingsControllerProvider.notifier);
    final minRule = settings.rules.minimumPoundsPerMile;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        body: Column(
          children: [
            HeroHeader(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Settings',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 26,
                          letterSpacing: -0.3)),
                  const SizedBox(height: 8),
                  Text(
                    '£${minRule.value.toStringAsFixed(2)}/mile · '
                    '${switch (settings.platformSelection) {
                      PlatformSelection.uber => 'Uber',
                      PlatformSelection.bolt => 'Bolt',
                      PlatformSelection.both => 'Both',
                    }} · '
                    '${settings.distanceUnit == DistanceUnit.miles ? 'Miles' : 'Kilometres'}',
                    style: const TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Minimum £ per mile',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '£${minRule.value.toStringAsFixed(2)}',
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final preset in _quickPresets)
                      ChoiceChip(
                        label: Text('£${preset.toStringAsFixed(2)}'),
                        selected: (minRule.value - preset).abs() < 0.001,
                        onSelected: (_) => controller.update(
                          (s) => s.copyWith(
                            rules: s.rules.copyWith(
                              minimumPoundsPerMile: minRule.copyWith(
                                  value: preset, enabled: true),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () => _showCustomValueDialog(
                      context, controller, minRule.value),
                  child: const Text('Enter a custom amount'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),
          Text('Platform', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          // A 3-way choice like this doesn't need three full-height list
          // rows with radio dots — the segmented control the Statistics
          // screen already uses for its range picker says the same thing
          // (Uber / Bolt / Both are mutually exclusive) in a third of the
          // vertical space, and the selected segment is unmistakable
          // without a separate radio glyph.
          SegmentedButton<PlatformSelection>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: PlatformSelection.uber, label: Text('Uber')),
              ButtonSegment(value: PlatformSelection.bolt, label: Text('Bolt')),
              ButtonSegment(value: PlatformSelection.both, label: Text('Both')),
            ],
            selected: {settings.platformSelection},
            onSelectionChanged: (s) =>
                controller.update((st) => st.copyWith(platformSelection: s.first)),
          ),
          const SizedBox(height: 28),
          Text('Distance unit', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          SegmentedButton<DistanceUnit>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: DistanceUnit.miles, label: Text('Miles')),
              ButtonSegment(value: DistanceUnit.kilometres, label: Text('Kilometres')),
            ],
            selected: {settings.distanceUnit},
            onSelectionChanged: (s) =>
                controller.update((st) => st.copyWith(distanceUnit: s.first)),
          ),
          const SizedBox(height: 28),
          Text('App name', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          SectionCard(
            child: TextFormField(
              initialValue: settings.appName,
              onFieldSubmitted: (value) {
                final trimmed = value.trim();
                if (trimmed.isNotEmpty) {
                  controller.update((s) => s.copyWith(appName: trimmed));
                }
              },
            ),
          ),
          const SizedBox(height: 28),
          SectionCard(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(
              children: [
                _SettingsLinkTile(
                  icon: Icons.rule_folder_outlined,
                  title: 'Advanced rules',
                  subtitle:
                      'Pickup distance, minimum fare, hourly rate, and more',
                  onTap:
                      () {}, // Rules tab is reachable from bottom navigation.
                ),
                const Divider(height: 1, indent: 68),
                _SettingsLinkTile(
                  icon: Icons.security_outlined,
                  title: 'Permissions & setup',
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                        builder: (_) => const PermissionsScreen()),
                  ),
                ),
                const Divider(height: 1, indent: 68),
                _SettingsLinkTile(
                  icon: Icons.science_outlined,
                  title: 'Simulation / test mode',
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SimulationScreen()),
                  ),
                ),
                if (kDebugMode) ...[
                  const Divider(height: 1, indent: 68),
                  _SettingsLinkTile(
                    icon: Icons.bug_report_outlined,
                    title: 'Developer debug screen',
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const DebugScreen()),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 24),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.error,
              side: BorderSide(color: Theme.of(context).colorScheme.error),
            ),
            onPressed: () => _confirmClearHistory(context, ref),
            icon: const Icon(Icons.delete_outline),
            label: const Text('Clear job history'),
          ),
        ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showCustomValueDialog(
    BuildContext context,
    SettingsController controller,
    double current,
  ) async {
    final textController =
        TextEditingController(text: current.toStringAsFixed(2));
    final result = await showDialog<double>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Custom minimum £/mile'),
        content: TextField(
          controller: textController,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(prefixText: '£'),
          autofocus: true,
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              final value = double.tryParse(textController.text);
              Navigator.pop(context, value);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (result == null ||
        result < AppConstants.minAllowedPoundsPerMile ||
        result > AppConstants.maxAllowedPoundsPerMile) {
      return;
    }

    await controller.update(
      (s) => s.copyWith(
        rules: s.rules.copyWith(
          minimumPoundsPerMile: s.rules.minimumPoundsPerMile
              .copyWith(value: result, enabled: true),
        ),
      ),
    );
  }

  Future<void> _confirmClearHistory(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear job history?'),
        content: const Text(
            'This permanently deletes all locally stored job history.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.error),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Clear'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await ref.read(jobHistoryControllerProvider.notifier).clearHistory();
    }
  }
}

/// A ListTile with a tinted-circle leading icon — matches [RuleIcon]'s
/// treatment on the Rules screen so both settings-style lists in the app
/// read as one consistent visual language rather than two different ones.
class _SettingsLinkTile extends StatelessWidget {
  const _SettingsLinkTile({
    required this.icon,
    required this.title,
    required this.onTap,
    this.subtitle,
  });

  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return ListTile(
      leading: TintedIconCircle(icon: icon, color: primary),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: subtitle != null ? Text(subtitle!) : null,
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }
}
